package teamProject;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.MemberDAO;


@WebServlet("/movie/*")
public class MovieController extends HttpServlet {
		MovieDAO movieDAO;
		MemberDAO memberDAO;
		public void init(ServletConfig config) throws ServletException { //초기화 시작시 한번만 실행
			movieDAO = new MovieDAO(); 
			memberDAO = new MemberDAO();
		}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}

	private void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nextPage = "";
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out=response.getWriter();
		String action = request.getPathInfo(); //  URL에 추가되어 있는 경로 정보를 리턴
		System.out.println("액션명: " + action);
		if(action==null || action.equals("/movie.do")) {
			nextPage = "/index.jsp";
			
		}else if (action.equals("/movieChart.do")) {
			nextPage = "/movieChart.jsp";
			
		}else if(action.equals("/remember.do")) {
			List movieList = movieDAO.listMovies();
			request.setAttribute("movieList", movieList);
			nextPage = "/remember.jsp";
			
		}else if(action.equals("/confession.do")) {
			List movieList = movieDAO.listMovies();
			request.setAttribute("movieList", movieList);
			nextPage = "/confession.jsp";
			
		}else if(action.equals("/ticket.do")) {
			List mvInfoList = movieDAO.ListMvInfo();
			request.setAttribute("mvInfoList", mvInfoList);
			nextPage = "/ticket.jsp";
			
		}else if(action.equals("/rememberTicket.do")) {
			List mvInfoList = movieDAO.ListMvInfo();
			request.setAttribute("mvInfoList", mvInfoList);
			nextPage = "/rememberTicket.jsp";
			
		}else if(action.equals("/confessionTicket.do")) {
			List mvInfoList = movieDAO.ListMvInfo();
			request.setAttribute("mvInfoList", mvInfoList);
			nextPage = "/confessionTicket.jsp";
			
		}else if (action.equals("/movieSeat.do")) {
			String mvTitle = request.getParameter("mvTitle");
			String theater = request.getParameter("theater");
			String showingDate = request.getParameter("showingDate");
			String showingTime = request.getParameter("showingTime");
			//MovieInfoVO movieInfoVO = movieDAO.seatCheck(mvTitle, theater, showingDate, showingTime);
			List<MovieInfoVO> movieInfoVO = movieDAO.seatCheck(mvTitle, theater, showingDate, showingTime);
			request.setAttribute("seatInfo", movieInfoVO);
			nextPage="/movieSeat.jsp";
			
		}else if (action.equals("/ticketComp.do")) {
			String mvTitle = request.getParameter("mvTitle");
			String theater = request.getParameter("theater");
			String showingDate = request.getParameter("showingDate");
			String showingTime = request.getParameter("showingTime");
			String seatNum = request.getParameter("seatNum");
			String bookNum = request.getParameter("bookNum");
			String id = request.getParameter("id");
			MovieInfoVO movieInfoVO = new MovieInfoVO();
			movieInfoVO.setMvTitle(mvTitle);
			movieInfoVO.setTheater(theater);
			movieInfoVO.setShowingDate(showingDate);
			movieInfoVO.setShowingTime(showingTime);
			movieInfoVO.setSeatNum(seatNum);
			movieInfoVO.setBookNum(bookNum);
			movieInfoVO.setId(id);
			movieDAO.addTicket(movieInfoVO);
			request.setAttribute("movieInfoVO", movieInfoVO);
			nextPage="/ticketComp.jsp";
			
		} else if (action.equals("/ticketCheck.do")) {
			try {
				String id = request.getParameter("_id");
				System.out.println("Movie컨트롤러 실행중 아이디 : "+id);
				List movieInfoVO = movieDAO.ticketChk(id);
				for(int i=0; i<movieInfoVO.size(); i++) {
					MovieInfoVO vo=(MovieInfoVO) movieInfoVO.get(i);
					System.out.println("아이디"+vo.getId());
					System.out.println("영화제목"+vo.getMvTitle());
					System.out.println("상영날짜"+vo.getShowingDate());
					System.out.println("상영시간"+vo.getShowingTime());
					System.out.println("상영관"+vo.getTheater());
					System.out.println("좌석번호"+vo.getSeatNum());
				}
				request.setAttribute("movieInfoVO", movieInfoVO);
				nextPage="/ticketCheck.jsp";
			} catch (Exception e) {
				System.out.println("ticketCheck.do 오류"+e);
			}
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(nextPage);
		dispatcher.forward(request, response);
		}
	}
